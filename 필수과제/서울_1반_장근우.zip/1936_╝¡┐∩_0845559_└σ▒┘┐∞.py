A=list(map(int,input().split()))
B=[[2,1],[3,2],[1,3]]
if A in B:
    print("A")
else:
    print("B")
